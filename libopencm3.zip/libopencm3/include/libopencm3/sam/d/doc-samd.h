/** @defgroup peripheral_apis Peripheral APIs
 * APIs for device peripherals
 */

/** @defgroup SAMD_defines SAMD Defines
 * Defined Constants and Types for the SAMD series.
 * @copyright SPDX: LGPL-3.0-or-later
 */
